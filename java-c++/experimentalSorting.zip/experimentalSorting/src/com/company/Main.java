/*
 *exoerimentalSorting.java
 * CSCI 112 Spring 2020
 * last edited April 27, 2020 by Jana Backman
 *
 *This program is an experimental program that tests the code for the time it takes to sort different
 * length arrays. It creates an array with 10000, 100000 and 1000000 integers depending on the exceution
 * the programmer needs to change the number to change the length of the array to sort. There are
 * also 4 methods to sort. The merge sort method, the quick sort method, the selection method and
 * the insertion method. All methods are coded in the program and the programer changes the code
 * calling a specific sorting method. Each time you run the program it goes 100 times and prints the
 * time in seconds it took to be sorted. In total we need to ecxecute the program 12 time to
 * reach the experiment and all the data needed.
 *
 */


package com.company;
import java.io.*;

public class Main {

    public static void main(String[] args) throws Exception{

        int size = 10000;//change to 100000 second run and 100000 third time
        //printing the title for the seconds it will print ahead
        System.out.print("Merge sort // ");//change depending on the sort method that using
        System.out.println("10000 elements");//change depending on the array length using

        // run 100 times
        for (int k = 0; k< 100; k++ ){
            int [] a = new int[size];


            //fill the array with random integers
            for (int i = 0; i < a.length; i++){
                a[i]= (int)(Math.random()*100000+1);
            }//end for
            //time when it starts to sort in nano time
            long startTime = System.nanoTime();

            //sort the array
            //call the method to use  depending on the method you want to use remove the backslashes
            //that make it a comment and run it. Don't forguet to comment the method you previously used
            //(in the merge method you can comment also the temp array when not using that method)

            //mergeSort
            int [] temp = new int[a.length];//empty temp array same size as a for merge method
            mergeSort(a, temp, 0, a.length - 1);

            //quickSort
            //quickSort(a, 0, a.length -1);

            //selection sort
            //selectionSort(a);

            //insertion sort
            //insertionSort(a);

            //the time when the array is sorted in nanotime
            long endTime = System.nanoTime();
            // this would calculate the time it took the program to run this code (the sorting)
            // by subtracting endTime from startTime
            long duration = endTime - startTime;

            //print the time it took to sort the array in seconds
            System.out.printf("%12.8f %n", (double)duration/100000000);


        }//end for (int k = 0; k< 100; k++ )
    }//end main()
    /*
     *############
     * MERGE SORT
     * ############
     */
    //Recursive method so sort array in a merge method. This method splits the array in 2
    //and then calls itself for the 2 halves until it reaches the point when the array has one element
    //then it calls the merge method to merge the 2 arrays back in an acending order
    public static void mergeSort(int[] a, int[] temp, int low, int high) {
        //  low is the low index of the part of the array to be sorted
        //  high is the high index of the part of the array to be sorted

        int mid;  // the middle of the array – last item in low half

        // if high > low then there is more than one item in the list to be sorted
        if (high > low) {

            // split into two halves and mergeSort each part

            // find middle (last element in low half)
            mid = (low+high)/2;
            mergeSort(a, temp, low, mid );
            mergeSort(a, temp, mid+1, high);

            // merge the two halves back together, sorting while merging
            merge(a, temp, low, mid, high);

        } // end if

        return;
    }// end mergerSort()
    //********************************************************************

    /* This method merges the two halves of the set being sorted back together.
     * the low half goes from a[low] to a[mid]
     * the high half goes from a[mid+1] to a[high]
     * (High and low only refer to index numbers, not the values in the array.)
     *
     * The work of sorting occurs as the two halves are merged back into one
     * sorted set.
     *
     * This version of mergeSort copies the set to be sorted into the same
     * locations in a temporary array, then sorts them as it puts them back.
     * Some versions of mergeSort sort into the temporary array then copy it back.
     */
    public static void merge(int[] a, int[] temp, int low, int mid, int high) {
        //  low is the low index of the part of the array to be sorted
        //  high is the high index of the part of the array to be sorted
        //  mid is the middle of the array – last item in low half

        // copy the two sets from a[] to the same locations in the temporary array
        for (int i = low; i <= high; i++) {
            temp[i] = a[i];
        }

        //set up necessary pointers
        int lowP = low;         // pointer to current item in low half
        int highP = mid + 1;    // pointer to current item in high half
        int aP = low;           // pointer to where each item will be put back in a[]

        // while the pointers have not yet reached the end of either half
        while ((lowP <= mid) && (highP <= high)) {

            // if current item in low half <= current item in high half
            if (temp[lowP] <= temp[highP]) {
                // move item at lowP back to array a and increment low pointer
                a[aP] = temp[lowP];
                lowP++;
            } else {
                // move item at highP back to array a and increment high pointer
                a[aP] = temp[highP];
                highP++;
            } // end if..else

            // increment pointer for location in original array
            aP++;
        } // end while

        /* When the while loop is done, either the low half or the high half is done.
         * We now simply move back everything in the half not yet done.
         * Remember, each half is already in order itself.
         */

        // if lowP has reached end of low half, then low half is done, move rest of high half
        if (lowP > mid)
            for (int i = highP; i <= high; i++) {
                a[aP] = temp[i];
                aP++;
            } // end for
        else // high half is done, move rest of low half

            for (int i = lowP; i <= mid; i++) {
                a[aP] = temp[i];
                aP++;
            }// end for

        return;
    } // end merge()
    // *************************************************************

    /*
     *############
     * QUICK SORT
     * ############
     */
    // the recursive quicksort method, which calls the partition method. This method would find a
    //pivot index by calling the partition() method then it calls itself to partition it again until
    //it sorts all the elements
    public static void quickSort(int[] a, int startIndex, int endIndex) {
        int pivotIndex;      // the index of pivot returned by the quicksort partition

        // if the set has more than one element, then partition
        if (startIndex < endIndex) {
            // partition and return the pivotIndex
            pivotIndex = partition(a, startIndex, endIndex);
            // quicksort the low set
            quickSort(a, startIndex, pivotIndex - 1);
            // quiclsort the high set
            quickSort(a, pivotIndex + 1, endIndex);
        } // end if
    } // end quickSort()
    //************************************************************************

    // This method performs quicksort partitioning on a set of elements in an array.
    //It find a pivot element and from there it separates the array to the left the numbers that are
    //lower than the pivot and to the right the larger numbers.
    public static int partition(int[] a, int startIndex, int endIndex) {

        int pivotIndex;             // the index of the chosen pivot element
        int pivot;                  // the value of the chosen pivot
        int midIndex = startIndex;  // boundary element between high and low sets

        // select the center element in the set as the pivot by integer averaging
        pivotIndex = (startIndex + endIndex) / 2;
        pivot = a[pivotIndex];

        // put the pivot at the end of the set so it is out of the way
        swap(a, pivotIndex, endIndex);

        // iterate the set, up to but not including last element
        for (int i = startIndex; i < endIndex; i++) {
            // if a[i] is less than the pivot
            if (a[i] < pivot) {

                // put a[i] in the low half and increment current Index
                swap(a, i, midIndex);
                midIndex = midIndex + 1;
            } // end if
        } // end for

        // partitioning complete -- move pivot from end to middle
        swap(a, midIndex, endIndex);

        // return index of pivot
        return midIndex;

    } // end partition
    //************************************************************************
    // This method swaps two elements in an integer array
    public static void swap(int[] a, int first, int second) {

        int c;  // a catalyst variable used for the swap

        c = a[first];
        a[first] = a[second];
        a[second] = c;

    } // end Swap()
    //************************************************************************

    /*
     *################
     * SELECTION SORT
     * ###############
     */
    // This method performs selection sort on a set of elements in an array.
    public static void selectionSort(int[] a) {

        for (int i = 0; i < a.length - 1; i++) {
            // Find the minimum in the list[i..list.length-1]
            int currentMin = a[i];
            int currentMinIndex = i;

            for (int j = i + 1; j < a.length; j++) {
                if (currentMin > a[j]) {
                    currentMin = a[j];
                    currentMinIndex = j;
                } // end if
            } // end for j

            // Swap list[i] with list[currentMinIndex] if necessary;
            if (currentMinIndex != i) {
                a[currentMinIndex] = a[i];
                a[i] = currentMin;
            } // end if
        } // end for i

    }  // end selectionSort()
    //************************************************************************
    /*
     *################
     * INSERTION SORT
     * ###############
     */
    //This method preforms insertion sort on an array a
    public static void insertionSort(int[] a) {

        int j;  // a loop counter -- declared early so it can be used after the loop


        for (int i = 1; i < a.length; i++) {

            /* insert a[i] into a sorted sublist a[0..i-1] so that
           list[0..i] is sorted. */
            int currentElement = a[i];

            for ( j = i - 1; j >= 0 && a[j] > currentElement; j--) {
                a[j + 1] = a[j];
            } // end for j

            // Insert the current element into a[j+1]
            a[j + 1] = currentElement;
        }

    }  // end insertionSort()
    //************************************************************************

}
