/*fibonacci.Java
 *CSCI 112, Spring 2020
 * Last edited April 12, 2020 by Jana Backman
 *
 * This program find the Fibonacci place of four input by user integers.
 * The porogram gives the user a choice to either find the fib place with
 * an iterative method or with a recursive method.
 */

package com.company;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		//variable to store the result of the fib Nth number after calling the method
		int result;
		//set up an instance of Scanner for input
		Scanner scr = new Scanner(System.in);
		//creating an array to store test values
		int[] testFib = new int[4];
		//iterating to enter each input value into array to be tested
		for (int i = 0; i < testFib.length; ++i) {
			System.out.println("Enter positive integer to calculate fibonacci ");
			int fibNum = scr.nextInt();
			testFib[i] = fibNum;
		}
		//asking the user to chose a method to find the Nth fob number
		System.out.println("choose the method you would like to use to find the Nth Fibonacci " +
				"\nplace of the number entered");
		System.out.println("For the iterative method press I");
		System.out.println("For the recusive method press R");
		//variable to store choice
		String choice = scr.next();
		//making choice an upper case if the user didn't
		choice = choice.toUpperCase();
		//option one using the iteration method
		if (choice.equals("I")) {
			//iterating through each value of the array to find fib number
			for (int value : testFib) {
				//calling the iteration method
				result = fibIteration(value);
				//print each number and it's fibonacci number
				System.out.printf("The %d Fibonacci place is %d \n", value, result);
			}//end for
		}//end if
		//second option using the recursive method
		else if(choice.equals("R")){
			//iterating the array values to find each value fibonacci's
			for (int value : testFib) {
				//calling the recurcive method
				result = fibRecursive(value);
				//printing each number and it's fibonacci number
				System.out.printf("The %d Fibonacci place is %d \n", value, result);
			}//end for
		}//end if
		//if user inputs a value that is not one of the options
		else{
			System.out.println(choice + " NOT an option");
			}
		}//end main

		//method that finds Nth fibonacci number by iterating all the numbers
		//that are smaller that the number choosed and uses a sum to add them
		//until reaching the number times
		public static int fibIteration ( int fibNum){
			//vatriables to start the fibonacci sequence
			int num1 = 0;
			int num2 = 1;
			//if fib number is 0 or one the return statement returns 0 or 1
			if (fibNum == 0 || fibNum == 1) {
				return fibNum;
			}//end if
			//for loop to iterate through the numbers to reach the fib number of selected number
			for (int i = 0; i < fibNum; ++i) {
				//adding number by sequence
				int sum = num1 + num2;
				num1 = num2;
				num2 = sum;
			}// end for loop
			return num1;

		}//end fibIteration() method

		//this method finds the fib number of the selected number by the user using
		//a recursive method that goes on until reaches the number 1
		public static int fibRecursive ( int fibNum){
			//if numbers chosed is 0
			if (fibNum == 0) {
				return 0;
			}//end if
			//if number chosed is 1
			else if (fibNum == 1) {
				return 1;
			} //end else if
			//else number -1 and number -2 are calling it self until reaching 1
			 else {
				return fibRecursive(fibNum - 1) + fibRecursive(fibNum - 2);
			}//end else
		}//end fibRecursive() method


	}//end class main
