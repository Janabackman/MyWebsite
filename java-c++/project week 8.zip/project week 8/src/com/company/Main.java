package com.company;
import java.io.*;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) throws Exception {
        Scanner src = new Scanner(System.in);
        System.out.println("Enter name of source directory to copy from: ");
        String sourceFile= src.nextLine();
        System.out.println("Enter name of destination directory to copy the files into: ");
        String destinationFile = (src.nextLine()+"/"+sourceFile);

        isDirFile("C:/"+sourceFile, destinationFile);

    }
    public static void isDirFile(String source, String dest) throws Exception{

        String newSource = new File(source).getName();
        File sourceFile = new File (source);
        File dirFile = new File (dest +"/"+  newSource);
        System.out.println(new File(source).getName());
        System.out.println("1"+dirFile);
        dirFile.mkdirs();

        File[] entries;

        if (dirFile.exists()){
            if (sourceFile.isDirectory()){
                entries = sourceFile.listFiles();
                assert entries != null;
                for (File entry:entries){
                    if(entry.isFile()){
                        copyFile(entry.getAbsolutePath(),dest+"/"+newSource);
                    }
                    else{
                        System.out.println(entry.getAbsolutePath());
                        isDirFile(entry.getAbsolutePath(),dest+"/"+newSource);

                    }
                }
            }
        }
        else{
            System.out.println("File does not exist");
        }
    }
    public static void copyFile(String source, String destination) throws Exception{
        File sourceFile;
        File destFile;

        FileInputStream sourceStream;
        FileOutputStream destSteam;

        BufferedInputStream bufferedSource = null;
        BufferedOutputStream bufferedDestination = null;
        try{

            sourceFile = new File(source);
            destFile = new File (destination, new File(source).getName());

            sourceStream = new FileInputStream(sourceFile);
            destSteam = new FileOutputStream(destFile);

            bufferedSource = new BufferedInputStream(sourceStream, 8182);
            bufferedDestination = new BufferedOutputStream(destSteam, 8182);

            int transfer;

            System.out.println("Beginning file copy: ");
            System.out.println("\tcopying "+ source);
            System.out.println("\tto      "+destination);

            while ((transfer = bufferedSource.read()) != -1){
                bufferedDestination.write(transfer);
            }

        }
        catch (IOException e){
            e.printStackTrace();
            System.out.println(" An unexpected I/O error occurred.");
        }
        finally {
            if(bufferedSource != null){
                bufferedSource.close();
            }
            if(bufferedDestination != null){
                bufferedDestination.close();
            }
            System.out.println("Files closed. Copy complete.");
        }
    }
}
