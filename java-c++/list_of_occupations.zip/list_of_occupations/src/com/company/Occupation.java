package com.company;

public class Occupation {
        //declaring variables
        private String cos;
        private String title;
        private int employment;
        private double  salary;

        //constructors
        public Occupation(){
            cos= "";
            title= "";
            employment= 0;
            salary= 0.0;
        }

        public Occupation(String cos, String title, int employment, double salary){
            this.cos= cos;
            this.title= title;
            this.employment= employment;
            this.salary= salary;
        }

        //accesors
        public String getCos(){
            return cos;
        }

        public String getTitle(){
            return title;
        }

        public int getEmployment(){
            return employment;
        }

        public double getSalary(){
            return salary;
        }

        //return as a string
        public String toString(){
            String info = ("COS= "+ cos +"\nTitle= "+ title+ "\nEmployment=" +employment+ "\nSalary= " + salary+"\n");
            return info;

        }


}
