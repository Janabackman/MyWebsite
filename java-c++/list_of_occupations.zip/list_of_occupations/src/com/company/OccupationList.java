package com.company;


import java.io.FileNotFoundException;
import java.util.Scanner;

public class OccupationList {
    private int count= 0;
    // create array to load with occupation objects
    public Occupation[] listOfOccupations = new Occupation[1000];

    public void loadArray() throws FileNotFoundException {

        java.io.File occupFile = new java.io.File("occupations-3.txt");

        Scanner infile = new Scanner(occupFile);


        //temporary variables to hold properties of list
        String cos;
        String title;
        int employment;
        double salary;
         // load the array of occupations
        while(infile.hasNextLine()){
            cos= infile.nextLine();
            title= infile.nextLine();
            employment= Integer.parseInt(infile.nextLine());
            salary= Double.parseDouble(infile.nextLine());
            listOfOccupations[count]= new Occupation(cos, title, employment, salary);
            count++;

        }
        infile.close();

    }
    // print the list of all occupation objects
    public void printAllOccupations(){
        for (count=0; count<804; count++) {
            System.out.println(listOfOccupations[count].toString() + (count+1) + "\n");
        }
    }
    // find occupation by lookup with COS
    public void find(String numEntered){
        int i;
        int a= 0;
        for (i=0; i<count; i++){
            if (numEntered.equals(listOfOccupations[i].getCos())) {
                System.out.println(listOfOccupations[i].toString());
                a++;
            }
        }
        if (a <= 0){
            System.out.println("NO OCCUPATION FOUND, TRY AGAIN!!");
        }

    }

}
