//Jana Backman
//Week 1 project
//CSCI 112
//

package com.company;


import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {


        OccupationList ol1=new OccupationList();
        ol1.loadArray();
        ol1.printAllOccupations();
         // to look up occupation
        Scanner scr = new Scanner(System.in);
        System.out.println("Enter COS of occupation you want to find information about enter exit to quit");
        String COS= scr.nextLine();

        while (!COS.equals("exit")) {
            ol1.find(COS);
            System.out.println("Enter COS of occupation you want to find information about enter exit to quit");
            COS = scr.nextLine();
            if (COS.equals("exit")){
                break;
            }

        }
    }

}
